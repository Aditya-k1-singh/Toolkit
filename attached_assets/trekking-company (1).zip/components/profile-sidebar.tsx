"use client"

import Link from "next/link"
import { usePathname, useRouter } from "next/navigation"
import { BookMarked, CreditCard, Heart, History, LogOut, Settings, User } from "lucide-react"

import { cn } from "@/lib/utils"
import { useAuth } from "@/context/auth-context"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

export default function ProfileSidebar() {
  const pathname = usePathname()
  const router = useRouter()
  const { user, logout } = useAuth()

  const handleLogout = () => {
    logout()
    router.push("/")
  }

  const getInitials = (email: string) => {
    if (!email) return "U"
    return email.charAt(0).toUpperCase()
  }

  const navItems = [
    {
      title: "Profile",
      href: "/profile",
      icon: User,
    },
    {
      title: "My Bookings",
      href: "/profile/bookings",
      icon: BookMarked,
    },
    {
      title: "Wishlist",
      href: "/profile/wishlist",
      icon: Heart,
    },
    {
      title: "Payment Methods",
      href: "/profile/payment",
      icon: CreditCard,
    },
    {
      title: "Trek History",
      href: "/profile/history",
      icon: History,
    },
    {
      title: "Settings",
      href: "/profile/settings",
      icon: Settings,
    },
  ]

  return (
    <aside className="w-full md:w-[240px]">
      <div className="flex flex-col items-center mb-6 p-4 border rounded-lg">
        <Avatar className="h-16 w-16 mb-3">
          <AvatarImage src="/placeholder-user.jpg" alt={user || "User"} />
          <AvatarFallback>{getInitials(user || "")}</AvatarFallback>
        </Avatar>
        <div className="text-center">
          <p className="font-medium">{user}</p>
          <p className="text-sm text-muted-foreground">Member since 2025</p>
        </div>
      </div>

      <nav className="flex flex-col space-y-1">
        {navItems.map((item) => (
          <Link key={item.href} href={item.href}>
            <span
              className={cn(
                "flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium hover:bg-accent hover:text-accent-foreground",
                pathname === item.href ? "bg-accent text-accent-foreground" : "transparent",
              )}
            >
              <item.icon className="h-4 w-4" />
              {item.title}
            </span>
          </Link>
        ))}
        <Button variant="destructive" className="justify-start mt-4 px-3" onClick={handleLogout}>
          <LogOut className="mr-3 h-4 w-4" />
          Logout
        </Button>
      </nav>
    </aside>
  )
}
