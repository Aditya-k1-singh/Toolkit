"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { MapPin, Calendar, Star } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { useRouter } from "next/navigation"
import { useAuth } from "@/context/auth-context"
import { useToast } from "@/components/ui/use-toast"

interface TrekCardProps {
  title: string
  location: string
  image: string
  price: number
  duration: number
  difficulty: string
  rating: number
  season: string
  slug: string
}

export default function TrekCard({
  title,
  location,
  image,
  price,
  duration,
  difficulty,
  rating,
  season,
  slug,
}: TrekCardProps) {
  const [isBookingOpen, setIsBookingOpen] = useState(false)
  const router = useRouter()
  const { isAuthenticated } = useAuth()
  const { toast } = useToast()

  const handleBookNow = () => {
    if (!isAuthenticated) {
      toast({
        title: "Login required",
        description: "Please login to book this trek",
      })
      router.push("/login")
      return
    }
    setIsBookingOpen(true)
  }

  const handleViewDetails = () => {
    router.push(`/treks/${slug}`)
  }

  return (
    <Card className="overflow-hidden flex flex-col h-full">
      <div className="aspect-[4/3] relative cursor-pointer" onClick={handleViewDetails}>
        <Image
          src={image || "/placeholder.svg"}
          alt={title}
          fill
          className="object-cover transition-transform hover:scale-105 duration-300"
        />
        <Badge className="absolute top-3 right-3">{difficulty}</Badge>
      </div>
      <CardHeader className="pb-2">
        <div className="flex justify-between items-start">
          <CardTitle className="text-xl">
            <Link href={`/treks/${slug}`} className="hover:text-primary transition-colors">
              {title}
            </Link>
          </CardTitle>
          <div className="flex items-center">
            <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
            <span className="text-sm ml-1">{rating}</span>
          </div>
        </div>
        <CardDescription className="flex items-center">
          <MapPin className="h-4 w-4 text-muted-foreground mr-1" />
          <span>{location}</span>
        </CardDescription>
      </CardHeader>
      <CardContent className="pb-2">
        <div className="flex justify-between text-sm">
          <div className="flex items-center gap-1">
            <Calendar className="h-4 w-4 text-muted-foreground" />
            <span>{duration} Days</span>
          </div>
          <div>
            <span className="text-muted-foreground">Best Season: </span>
            <span>{season}</span>
          </div>
        </div>
      </CardContent>
      <CardFooter className="flex justify-between mt-auto">
        <p className="font-semibold">₹{price.toLocaleString()}</p>
        <div className="flex gap-2">
          <Button size="sm" variant="outline" onClick={handleViewDetails}>
            Details
          </Button>
          <Button size="sm" onClick={handleBookNow}>
            Book Now
          </Button>
        </div>
      </CardFooter>
    </Card>
  )
}
