"use client"

import { useState } from "react"
import { Search, Sliders } from "lucide-react"
import { useRouter } from "next/navigation"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Slider } from "@/components/ui/slider"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { useToast } from "@/components/ui/use-toast"
import { treks } from "@/data/treks"

export default function SearchFilters() {
  const router = useRouter()
  const { toast } = useToast()
  const [priceRange, setPriceRange] = useState([5000, 25000])
  const [durationRange, setDurationRange] = useState([3, 10])
  const [searchQuery, setSearchQuery] = useState("")
  const [location, setLocation] = useState("")
  const [season, setSeason] = useState("")
  const [difficulty, setDifficulty] = useState<string[]>([])
  const [features, setFeatures] = useState<string[]>([])

  const handleDifficultyChange = (value: string) => {
    setDifficulty((prev) => {
      if (prev.includes(value)) {
        return prev.filter((item) => item !== value)
      } else {
        return [...prev, value]
      }
    })
  }

  const handleFeatureChange = (value: string) => {
    setFeatures((prev) => {
      if (prev.includes(value)) {
        return prev.filter((item) => item !== value)
      } else {
        return [...prev, value]
      }
    })
  }

  const handleSearch = () => {
    // In a real app, this would filter treks based on criteria and update the UI
    // For now, we'll just show a toast with the search criteria

    const filteredTreks = treks.filter((trek) => {
      // Filter by search query (title or location)
      if (
        searchQuery &&
        !trek.title.toLowerCase().includes(searchQuery.toLowerCase()) &&
        !trek.location.toLowerCase().includes(searchQuery.toLowerCase())
      ) {
        return false
      }

      // Filter by location
      if (location && trek.location !== location) {
        return false
      }

      // Filter by season
      if (season && trek.season !== season) {
        return false
      }

      // Filter by price range
      if (trek.price < priceRange[0] || trek.price > priceRange[1]) {
        return false
      }

      // Filter by duration range
      if (trek.duration < durationRange[0] || trek.duration > durationRange[1]) {
        return false
      }

      // Filter by difficulty
      if (difficulty.length > 0 && !difficulty.some((d) => trek.difficulty.includes(d))) {
        return false
      }

      return true
    })

    toast({
      title: `Found ${filteredTreks.length} treks`,
      description: `Matching your search criteria`,
    })

    // In a real app, we would update the UI with the filtered treks
    // For demonstration, we'll navigate to the first matching trek if available
    if (filteredTreks.length > 0) {
      router.push(`/treks/${filteredTreks[0].slug}`)
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row gap-4">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search treks..."
            className="pl-9"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <div className="flex-1 flex gap-4">
          <Select value={location} onValueChange={setLocation}>
            <SelectTrigger className="flex-1">
              <SelectValue placeholder="Location" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Locations</SelectItem>
              <SelectItem value="Uttarakhand">Uttarakhand</SelectItem>
              <SelectItem value="Himachal Pradesh">Himachal Pradesh</SelectItem>
              <SelectItem value="Kashmir">Kashmir</SelectItem>
              <SelectItem value="Sikkim">Sikkim</SelectItem>
              <SelectItem value="Karnataka">Karnataka</SelectItem>
              <SelectItem value="Kerala">Kerala</SelectItem>
              <SelectItem value="Maharashtra">Maharashtra</SelectItem>
            </SelectContent>
          </Select>
          <Select value={season} onValueChange={setSeason}>
            <SelectTrigger className="flex-1">
              <SelectValue placeholder="Season" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Seasons</SelectItem>
              <SelectItem value="Summer">Summer</SelectItem>
              <SelectItem value="Monsoon">Monsoon</SelectItem>
              <SelectItem value="Autumn">Autumn</SelectItem>
              <SelectItem value="Winter">Winter</SelectItem>
              <SelectItem value="Spring">Spring</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <Accordion type="single" collapsible className="w-full">
        <AccordionItem value="advanced-filters">
          <AccordionTrigger className="text-sm font-medium">
            <div className="flex items-center gap-2">
              <Sliders className="h-4 w-4" />
              Advanced Filters
            </div>
          </AccordionTrigger>
          <AccordionContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4">
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between mb-2">
                    <Label>Price Range (₹)</Label>
                    <span className="text-sm">
                      ₹{priceRange[0].toLocaleString()} - ₹{priceRange[1].toLocaleString()}
                    </span>
                  </div>
                  <Slider defaultValue={priceRange} min={1000} max={50000} step={1000} onValueChange={setPriceRange} />
                </div>
                <div>
                  <div className="flex justify-between mb-2">
                    <Label>Duration (Days)</Label>
                    <span className="text-sm">
                      {durationRange[0]} - {durationRange[1]} days
                    </span>
                  </div>
                  <Slider defaultValue={durationRange} min={1} max={15} step={1} onValueChange={setDurationRange} />
                </div>
              </div>
              <div className="space-y-4">
                <div>
                  <Label className="mb-2 block">Difficulty Level</Label>
                  <div className="space-y-2">
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="easy"
                        checked={difficulty.includes("Easy")}
                        onCheckedChange={() => handleDifficultyChange("Easy")}
                      />
                      <label htmlFor="easy" className="text-sm">
                        Easy
                      </label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="moderate"
                        checked={difficulty.includes("Moderate")}
                        onCheckedChange={() => handleDifficultyChange("Moderate")}
                      />
                      <label htmlFor="moderate" className="text-sm">
                        Moderate
                      </label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="difficult"
                        checked={difficulty.includes("Difficult")}
                        onCheckedChange={() => handleDifficultyChange("Difficult")}
                      />
                      <label htmlFor="difficult" className="text-sm">
                        Difficult
                      </label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="challenging"
                        checked={difficulty.includes("Challenging")}
                        onCheckedChange={() => handleDifficultyChange("Challenging")}
                      />
                      <label htmlFor="challenging" className="text-sm">
                        Challenging
                      </label>
                    </div>
                  </div>
                </div>
                <div>
                  <Label className="mb-2 block">Special Features</Label>
                  <div className="space-y-2">
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="waterfalls"
                        checked={features.includes("Waterfalls")}
                        onCheckedChange={() => handleFeatureChange("Waterfalls")}
                      />
                      <label htmlFor="waterfalls" className="text-sm">
                        Waterfalls
                      </label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="lakes"
                        checked={features.includes("Lakes")}
                        onCheckedChange={() => handleFeatureChange("Lakes")}
                      />
                      <label htmlFor="lakes" className="text-sm">
                        Lakes
                      </label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="peaks"
                        checked={features.includes("Mountain Peaks")}
                        onCheckedChange={() => handleFeatureChange("Mountain Peaks")}
                      />
                      <label htmlFor="peaks" className="text-sm">
                        Mountain Peaks
                      </label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="camping"
                        checked={features.includes("Camping")}
                        onCheckedChange={() => handleFeatureChange("Camping")}
                      />
                      <label htmlFor="camping" className="text-sm">
                        Camping
                      </label>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>
      </Accordion>

      <Button className="w-full" onClick={handleSearch}>
        Search Treks
      </Button>
    </div>
  )
}
