"use client"

import type React from "react"

import { useState } from "react"
import { CreditCard } from "lucide-react"

import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/components/ui/use-toast"
import { useRouter } from "next/navigation"

interface BookingFormProps {
  isOpen: boolean
  onClose: () => void
  trek: any
}

export default function BookingForm({ isOpen, onClose, trek }: BookingFormProps) {
  const [step, setStep] = useState(1)
  const [isLoading, setIsLoading] = useState(false)
  const [formData, setFormData] = useState({
    batch: "",
    participants: "1",
    addons: [] as string[],
    name: "",
    email: "",
    phone: "",
    paymentMethod: "card",
  })
  const { toast } = useToast()
  const router = useRouter()

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSelectChange = (name: string, value: string) => {
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1500))

      toast({
        title: "Booking successful!",
        description: "Your trek has been booked successfully.",
      })

      // Reset form and close dialog
      setFormData({
        batch: "",
        participants: "1",
        addons: [],
        name: "",
        email: "",
        phone: "",
        paymentMethod: "card",
      })
      setStep(1)
      onClose()

      // Redirect to bookings page
      router.push("/profile/bookings")
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Booking failed",
        description: "There was an error processing your booking. Please try again.",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const nextStep = () => setStep(step + 1)
  const prevStep = () => setStep(step - 1)

  const calculateTotal = () => {
    const basePrice = trek.price * Number.parseInt(formData.participants || "1")
    // Add addon prices if needed
    return basePrice
  }

  const handleClose = () => {
    setStep(1)
    onClose()
  }

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Book {trek.title}</DialogTitle>
          <DialogDescription>Complete your booking details to secure your spot on this amazing trek.</DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit}>
          {step === 1 && (
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="batch">Select Batch</Label>
                <Select value={formData.batch} onValueChange={(value) => handleSelectChange("batch", value)} required>
                  <SelectTrigger>
                    <SelectValue placeholder="Select a batch" />
                  </SelectTrigger>
                  <SelectContent>
                    {trek.batches.map((batch: any, index: number) => (
                      <SelectItem key={index} value={batch.date}>
                        <div className="flex items-center justify-between w-full">
                          <span>{batch.date}</span>
                          <span className="text-xs text-muted-foreground">{batch.spotsLeft} spots left</span>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="grid gap-2">
                <Label htmlFor="participants">Number of Participants</Label>
                <Select
                  value={formData.participants}
                  onValueChange={(value) => handleSelectChange("participants", value)}
                  required
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select number of participants" />
                  </SelectTrigger>
                  <SelectContent>
                    {[1, 2, 3, 4, 5, 6].map((num) => (
                      <SelectItem key={num} value={num.toString()}>
                        {num} {num === 1 ? "Person" : "People"}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="grid gap-2">
                <Label>Add-ons (Optional)</Label>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id="photography"
                      className="rounded border-gray-300"
                      onChange={(e) => {
                        if (e.target.checked) {
                          setFormData((prev) => ({
                            ...prev,
                            addons: [...prev.addons, "photography"],
                          }))
                        } else {
                          setFormData((prev) => ({
                            ...prev,
                            addons: prev.addons.filter((addon) => addon !== "photography"),
                          }))
                        }
                      }}
                    />
                    <Label htmlFor="photography">Photography Package (₹2,500)</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id="equipment"
                      className="rounded border-gray-300"
                      onChange={(e) => {
                        if (e.target.checked) {
                          setFormData((prev) => ({
                            ...prev,
                            addons: [...prev.addons, "equipment"],
                          }))
                        } else {
                          setFormData((prev) => ({
                            ...prev,
                            addons: prev.addons.filter((addon) => addon !== "equipment"),
                          }))
                        }
                      }}
                    />
                    <Label htmlFor="equipment">Trekking Equipment (₹3,000)</Label>
                  </div>
                </div>
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="name">Full Name</Label>
                <Input
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  placeholder="Enter your full name"
                  required
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  name="email"
                  type="email"
                  value={formData.email}
                  onChange={handleChange}
                  placeholder="Enter your email"
                  required
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="phone">Phone Number</Label>
                <Input
                  id="phone"
                  name="phone"
                  value={formData.phone}
                  onChange={handleChange}
                  placeholder="Enter your phone number"
                  required
                />
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label>Payment Method</Label>
                <RadioGroup
                  value={formData.paymentMethod}
                  onValueChange={(value) => handleSelectChange("paymentMethod", value)}
                  className="grid grid-cols-1 gap-2"
                >
                  <div className="flex items-center space-x-2 rounded-md border p-3">
                    <RadioGroupItem value="card" id="card" />
                    <Label htmlFor="card" className="flex items-center gap-2 cursor-pointer">
                      <CreditCard className="h-4 w-4" /> Credit/Debit Card
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2 rounded-md border p-3">
                    <RadioGroupItem value="upi" id="upi" />
                    <Label htmlFor="upi" className="cursor-pointer">
                      UPI
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2 rounded-md border p-3">
                    <RadioGroupItem value="netbanking" id="netbanking" />
                    <Label htmlFor="netbanking" className="cursor-pointer">
                      Net Banking
                    </Label>
                  </div>
                </RadioGroup>
              </div>

              <div className="rounded-md bg-muted p-4 space-y-3">
                <h3 className="font-medium">Booking Summary</h3>
                <div className="space-y-1 text-sm">
                  <div className="flex justify-between">
                    <span>Trek</span>
                    <span>{trek.title}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Batch</span>
                    <span>{formData.batch}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Participants</span>
                    <span>{formData.participants}</span>
                  </div>
                  <div className="flex justify-between font-medium pt-2 border-t">
                    <span>Total Amount</span>
                    <span>₹{calculateTotal().toLocaleString()}</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          <DialogFooter className="flex items-center justify-between">
            {step > 1 ? (
              <Button type="button" variant="outline" onClick={prevStep}>
                Back
              </Button>
            ) : (
              <Button type="button" variant="outline" onClick={handleClose}>
                Cancel
              </Button>
            )}
            {step < 3 ? (
              <Button type="button" onClick={nextStep}>
                Next
              </Button>
            ) : (
              <Button type="submit" disabled={isLoading}>
                {isLoading ? "Processing..." : "Complete Booking"}
              </Button>
            )}
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
