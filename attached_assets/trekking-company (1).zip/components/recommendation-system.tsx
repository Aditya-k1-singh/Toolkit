"use client"

import { Badge } from "@/components/ui/badge"

import type React from "react"

import { useState } from "react"

import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import TrekCard from "@/components/trek-card"

export default function RecommendationSystem() {
  const [step, setStep] = useState(1)
  const [showResults, setShowResults] = useState(false)
  const [budget, setBudget] = useState([10000, 20000])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setShowResults(true)
  }

  if (showResults) {
    return (
      <div className="space-y-6">
        <div className="bg-muted p-4 rounded-lg">
          <h3 className="font-medium mb-2">Based on your preferences, we recommend:</h3>
          <div className="flex flex-wrap gap-2">
            <Badge variant="outline" className="bg-background">
              Summer Trek
            </Badge>
            <Badge variant="outline" className="bg-background">
              Moderate Difficulty
            </Badge>
            <Badge variant="outline" className="bg-background">
              ₹10,000-₹20,000
            </Badge>
            <Badge variant="outline" className="bg-background">
              Wildlife
            </Badge>
            <Badge variant="outline" className="bg-background">
              Photography
            </Badge>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <TrekCard
            title="Valley of Flowers"
            location="Uttarakhand"
            image="/placeholder.svg?height=400&width=600"
            price={12500}
            duration={6}
            difficulty="Moderate"
            rating={4.8}
            season="Monsoon"
          />
          <TrekCard
            title="Hampta Pass"
            location="Himachal Pradesh"
            image="/placeholder.svg?height=400&width=600"
            price={14800}
            duration={5}
            difficulty="Moderate"
            rating={4.7}
            season="Summer"
          />
          <TrekCard
            title="Tarsar Marsar"
            location="Kashmir"
            image="/placeholder.svg?height=400&width=600"
            price={18900}
            duration={7}
            difficulty="Moderate"
            rating={4.9}
            season="Summer"
          />
        </div>

        <div className="flex justify-between">
          <Button
            variant="outline"
            onClick={() => {
              setShowResults(false)
              setStep(1)
            }}
          >
            Start Over
          </Button>
          <Button>View All Matches</Button>
        </div>
      </div>
    )
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {step === 1 && (
        <div className="space-y-6">
          <div>
            <h3 className="text-lg font-medium mb-4">When do you want to trek?</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Preferred Season</Label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Select season" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="summer">Summer (April-June)</SelectItem>
                    <SelectItem value="monsoon">Monsoon (July-September)</SelectItem>
                    <SelectItem value="autumn">Autumn (October-November)</SelectItem>
                    <SelectItem value="winter">Winter (December-February)</SelectItem>
                    <SelectItem value="spring">Spring (March-April)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Trip Duration</Label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Select duration" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="weekend">Weekend (2-3 days)</SelectItem>
                    <SelectItem value="short">Short Trip (4-6 days)</SelectItem>
                    <SelectItem value="medium">Medium Trip (7-10 days)</SelectItem>
                    <SelectItem value="long">Long Trip (10+ days)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          <div>
            <div className="flex justify-between mb-2">
              <Label>Budget Range (₹)</Label>
              <span className="text-sm">
                ₹{budget[0].toLocaleString()} - ₹{budget[1].toLocaleString()}
              </span>
            </div>
            <Slider defaultValue={budget} min={5000} max={50000} step={1000} onValueChange={setBudget} />
          </div>

          <div className="flex justify-end">
            <Button type="button" onClick={() => setStep(2)}>
              Next
            </Button>
          </div>
        </div>
      )}

      {step === 2 && (
        <div className="space-y-6">
          <div>
            <h3 className="text-lg font-medium mb-4">What are you looking for in a trek?</h3>
            <div className="space-y-4">
              <div>
                <Label className="mb-2 block">Difficulty Level</Label>
                <RadioGroup defaultValue="moderate">
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="easy" id="easy" />
                    <Label htmlFor="easy">Easy - Suitable for beginners</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="moderate" id="moderate" />
                    <Label htmlFor="moderate">Moderate - Some trekking experience helpful</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="difficult" id="difficult" />
                    <Label htmlFor="difficult">Difficult - For experienced trekkers</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="challenging" id="challenging" />
                    <Label htmlFor="challenging">Challenging - Requires excellent fitness</Label>
                  </div>
                </RadioGroup>
              </div>

              <div>
                <Label className="mb-2 block">Interests (Select all that apply)</Label>
                <div className="grid grid-cols-2 gap-2">
                  <div className="flex items-center space-x-2">
                    <Checkbox id="photography" />
                    <label htmlFor="photography" className="text-sm">
                      Photography
                    </label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox id="wildlife" />
                    <label htmlFor="wildlife" className="text-sm">
                      Wildlife
                    </label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox id="camping" />
                    <label htmlFor="camping" className="text-sm">
                      Camping
                    </label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox id="culture" />
                    <label htmlFor="culture" className="text-sm">
                      Local Culture
                    </label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox id="adventure" />
                    <label htmlFor="adventure" className="text-sm">
                      Adventure Activities
                    </label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox id="meditation" />
                    <label htmlFor="meditation" className="text-sm">
                      Meditation/Yoga
                    </label>
                  </div>
                </div>
              </div>

              <div>
                <Label htmlFor="special-requests" className="mb-2 block">
                  Any special requests?
                </Label>
                <Textarea
                  id="special-requests"
                  placeholder="Tell us if you have any specific requirements or preferences..."
                  className="resize-none"
                />
              </div>
            </div>
          </div>

          <div className="flex justify-between">
            <Button type="button" variant="outline" onClick={() => setStep(1)}>
              Back
            </Button>
            <Button type="submit">Get Recommendations</Button>
          </div>
        </div>
      )}
    </form>
  )
}
