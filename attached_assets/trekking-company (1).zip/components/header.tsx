"use client"

import Link from "next/link"
import { MapPin, Menu, User, LogOut } from "lucide-react"
import { useState } from "react"
import { useRouter } from "next/navigation"

import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { useAuth } from "@/context/auth-context"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

export default function Header() {
  const { user, logout, isAuthenticated } = useAuth()
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const router = useRouter()

  const handleLogout = () => {
    logout()
    setIsMenuOpen(false)
  }

  const getInitials = (email: string) => {
    if (!email) return "U"
    return email.charAt(0).toUpperCase()
  }

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between">
        <Link href="/" className="flex items-center gap-2 font-bold text-xl">
          <MapPin className="h-6 w-6 text-primary" />
          <span>TrekIndia</span>
        </Link>
        <nav className="hidden md:flex gap-6">
          <Link href="/#treks" className="text-sm font-medium hover:text-primary">
            Treks
          </Link>
          <Link href="/#upcoming" className="text-sm font-medium hover:text-primary">
            Upcoming
          </Link>
          <Link href="/#recent" className="text-sm font-medium hover:text-primary">
            Recent
          </Link>
          <Link href="/#testimonials" className="text-sm font-medium hover:text-primary">
            Testimonials
          </Link>
          <Link href="/#contact" className="text-sm font-medium hover:text-primary">
            Contact
          </Link>
        </nav>
        <div className="flex items-center gap-4">
          {isAuthenticated ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="rounded-full">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src="/placeholder-user.jpg" alt={user || "User"} />
                    <AvatarFallback>{getInitials(user || "")}</AvatarFallback>
                  </Avatar>
                  <span className="sr-only">User menu</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem className="font-medium">{user}</DropdownMenuItem>
                <DropdownMenuItem onClick={() => router.push("/profile")}>
                  <User className="mr-2 h-4 w-4" />
                  My Profile
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => router.push("/profile/bookings")}>My Bookings</DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleLogout}>
                  <LogOut className="mr-2 h-4 w-4" />
                  Logout
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <>
              <Link href="/login">
                <Button variant="outline">Login</Button>
              </Link>
              <Link href="/signup" className="hidden sm:block">
                <Button>Sign Up</Button>
              </Link>
            </>
          )}
          <Sheet open={isMenuOpen} onOpenChange={setIsMenuOpen}>
            <SheetTrigger asChild>
              <Button variant="outline" size="icon" className="md:hidden">
                <Menu className="h-6 w-6" />
                <span className="sr-only">Toggle navigation menu</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="left">
              <Link href="/" className="flex items-center gap-2 font-bold text-xl mb-6">
                <MapPin className="h-6 w-6 text-primary" />
                <span>TrekIndia</span>
              </Link>
              <div className="grid gap-2 py-6">
                <Link
                  href="#treks"
                  className="flex w-full items-center py-2 text-lg font-semibold"
                  onClick={() => setIsMenuOpen(false)}
                >
                  Treks
                </Link>
                <Link
                  href="#upcoming"
                  className="flex w-full items-center py-2 text-lg font-semibold"
                  onClick={() => setIsMenuOpen(false)}
                >
                  Upcoming
                </Link>
                <Link
                  href="#recent"
                  className="flex w-full items-center py-2 text-lg font-semibold"
                  onClick={() => setIsMenuOpen(false)}
                >
                  Recent
                </Link>
                <Link
                  href="#testimonials"
                  className="flex w-full items-center py-2 text-lg font-semibold"
                  onClick={() => setIsMenuOpen(false)}
                >
                  Testimonials
                </Link>
                <Link
                  href="#contact"
                  className="flex w-full items-center py-2 text-lg font-semibold"
                  onClick={() => setIsMenuOpen(false)}
                >
                  Contact
                </Link>
                {isAuthenticated ? (
                  <div className="mt-4 border-t pt-4">
                    <div className="flex items-center gap-3 mb-4">
                      <Avatar className="h-8 w-8">
                        <AvatarImage src="/placeholder-user.jpg" alt={user || "User"} />
                        <AvatarFallback>{getInitials(user || "")}</AvatarFallback>
                      </Avatar>
                      <span className="font-medium">{user}</span>
                    </div>
                    <div className="space-y-2">
                      <Link
                        href="/profile"
                        className="flex w-full items-center gap-2 py-2"
                        onClick={() => setIsMenuOpen(false)}
                      >
                        <User className="h-4 w-4" />
                        My Profile
                      </Link>
                      <Link
                        href="/profile/bookings"
                        className="flex w-full items-center gap-2 py-2"
                        onClick={() => setIsMenuOpen(false)}
                      >
                        My Bookings
                      </Link>
                      <Button variant="destructive" className="w-full mt-2" onClick={handleLogout}>
                        <LogOut className="mr-2 h-4 w-4" />
                        Logout
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="flex flex-col gap-2 mt-4">
                    <Link href="/login" onClick={() => setIsMenuOpen(false)}>
                      <Button variant="outline" className="w-full">
                        Login
                      </Button>
                    </Link>
                    <Link href="/signup" onClick={() => setIsMenuOpen(false)}>
                      <Button className="w-full">Sign Up</Button>
                    </Link>
                  </div>
                )}
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  )
}
