import { Star, StarHalf, User } from "lucide-react"

import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

interface TestimonialCardProps {
  name: string
  trek: string
  image: string
  rating: number
  testimonial: string
}

export default function TestimonialCard({ name, trek, image, rating, testimonial }: TestimonialCardProps) {
  // Generate star rating
  const renderStars = () => {
    const stars = []
    const fullStars = Math.floor(rating)
    const hasHalfStar = rating % 1 !== 0

    for (let i = 0; i < fullStars; i++) {
      stars.push(<Star key={`star-${i}`} className="h-4 w-4 fill-yellow-400 text-yellow-400" />)
    }

    if (hasHalfStar) {
      stars.push(<StarHalf key="half-star" className="h-4 w-4 fill-yellow-400 text-yellow-400" />)
    }

    return stars
  }

  return (
    <Card className="h-full">
      <CardHeader className="pb-3">
        <div className="flex items-center gap-3">
          <Avatar className="h-10 w-10">
            <AvatarImage src={image || "/placeholder.svg"} alt={name} />
            <AvatarFallback>
              <User className="h-5 w-5" />
            </AvatarFallback>
          </Avatar>
          <div>
            <h3 className="font-medium">{name}</h3>
            <p className="text-sm text-muted-foreground">{trek} Trek</p>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="flex mb-2">{renderStars()}</div>
        <p className="text-sm text-muted-foreground italic">"{testimonial}"</p>
      </CardContent>
    </Card>
  )
}
