"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import { useParams, useRouter } from "next/navigation"
import {
  ArrowLeft,
  Calendar,
  Clock,
  Compass,
  MapPin,
  Mountain,
  Star,
  ThermometerSun,
  Users,
  Wallet,
} from "lucide-react"

import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"
import { Progress } from "@/components/ui/progress"
import Header from "@/components/header"
import BookingForm from "@/components/booking-form"
import { useToast } from "@/components/ui/use-toast"
import { useAuth } from "@/context/auth-context"
import { treks } from "@/data/treks"

export default function TrekDetailsPage() {
  const params = useParams()
  const router = useRouter()
  const { toast } = useToast()
  const { isAuthenticated } = useAuth()
  const [isBookingOpen, setIsBookingOpen] = useState(false)
  const [trek, setTrek] = useState<any>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Find the trek by slug
    const foundTrek = treks.find((t) => t.slug === params.slug)
    if (foundTrek) {
      setTrek(foundTrek)
    } else {
      // If trek not found, redirect to 404 or home
      toast({
        variant: "destructive",
        title: "Trek not found",
        description: "The trek you're looking for doesn't exist.",
      })
      router.push("/")
    }
    setIsLoading(false)
  }, [params.slug, router, toast])

  const handleBookNow = () => {
    if (!isAuthenticated) {
      toast({
        title: "Login required",
        description: "Please login to book this trek",
      })
      router.push("/login")
      return
    }
    setIsBookingOpen(true)
  }

  if (isLoading || !trek) {
    return (
      <div className="flex min-h-screen flex-col">
        <Header />
        <main className="container py-8 flex-1">
          <div className="flex items-center space-x-4">
            <div className="h-12 w-12 rounded-full bg-muted animate-pulse"></div>
            <div className="space-y-2">
              <div className="h-4 w-[250px] rounded bg-muted animate-pulse"></div>
              <div className="h-4 w-[200px] rounded bg-muted animate-pulse"></div>
            </div>
          </div>
          <div className="mt-8 h-[400px] w-full rounded-xl bg-muted animate-pulse"></div>
        </main>
      </div>
    )
  }

  return (
    <div className="flex min-h-screen flex-col">
      <Header />

      <main className="flex-1">
        {/* Hero Section */}
        <div className="relative h-[50vh] md:h-[60vh] lg:h-[70vh]">
          <Image
            src={trek.coverImage || "/placeholder.svg"}
            alt={trek.title}
            fill
            className="object-cover brightness-75"
            priority
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent">
            <div className="container flex h-full flex-col justify-end pb-8">
              <Link
                href="/#treks"
                className="mb-4 flex w-fit items-center gap-1 rounded-full bg-black/30 px-3 py-1 text-sm text-white backdrop-blur-sm transition-colors hover:bg-black/50"
              >
                <ArrowLeft className="h-4 w-4" /> Back to all treks
              </Link>
              <div className="space-y-2">
                <div className="flex flex-wrap items-center gap-2">
                  <Badge className="bg-primary/90 text-primary-foreground">{trek.difficulty}</Badge>
                  <Badge variant="outline" className="border-white/50 text-white">
                    {trek.season}
                  </Badge>
                  <div className="flex items-center gap-1 rounded-full bg-black/30 px-2 py-0.5 text-sm text-white backdrop-blur-sm">
                    <Star className="h-3.5 w-3.5 fill-yellow-400 text-yellow-400" />
                    <span>{trek.rating}</span>
                  </div>
                </div>
                <h1 className="text-3xl font-bold text-white md:text-4xl lg:text-5xl">{trek.title}</h1>
                <p className="flex items-center gap-1 text-lg text-white/90">
                  <MapPin className="h-4 w-4" /> {trek.location}
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="container py-8">
          <div className="grid grid-cols-1 gap-8 lg:grid-cols-3">
            {/* Main Content */}
            <div className="lg:col-span-2">
              <Tabs defaultValue="overview">
                <TabsList className="w-full justify-start">
                  <TabsTrigger value="overview">Overview</TabsTrigger>
                  <TabsTrigger value="itinerary">Itinerary</TabsTrigger>
                  <TabsTrigger value="inclusions">Inclusions</TabsTrigger>
                  <TabsTrigger value="reviews">Reviews</TabsTrigger>
                </TabsList>

                <TabsContent value="overview" className="mt-6 space-y-6">
                  <div className="space-y-4">
                    <h2 className="text-2xl font-bold">About this Trek</h2>
                    <p className="text-muted-foreground">{trek.description}</p>

                    <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
                      <Card>
                        <CardContent className="flex flex-col items-center justify-center p-4">
                          <Calendar className="h-6 w-6 text-primary" />
                          <p className="mt-2 text-sm font-medium">{trek.duration} Days</p>
                          <p className="text-xs text-muted-foreground">Duration</p>
                        </CardContent>
                      </Card>
                      <Card>
                        <CardContent className="flex flex-col items-center justify-center p-4">
                          <Mountain className="h-6 w-6 text-primary" />
                          <p className="mt-2 text-sm font-medium">{trek.altitude} m</p>
                          <p className="text-xs text-muted-foreground">Max Altitude</p>
                        </CardContent>
                      </Card>
                      <Card>
                        <CardContent className="flex flex-col items-center justify-center p-4">
                          <ThermometerSun className="h-6 w-6 text-primary" />
                          <p className="mt-2 text-sm font-medium">{trek.season}</p>
                          <p className="text-xs text-muted-foreground">Best Season</p>
                        </CardContent>
                      </Card>
                      <Card>
                        <CardContent className="flex flex-col items-center justify-center p-4">
                          <Compass className="h-6 w-6 text-primary" />
                          <p className="mt-2 text-sm font-medium">{trek.difficulty}</p>
                          <p className="text-xs text-muted-foreground">Difficulty</p>
                        </CardContent>
                      </Card>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h3 className="text-xl font-bold">Highlights</h3>
                    <ul className="ml-6 list-disc space-y-2 text-muted-foreground">
                      {trek.highlights.map((highlight: string, index: number) => (
                        <li key={index}>{highlight}</li>
                      ))}
                    </ul>
                  </div>

                  <div className="space-y-4">
                    <h3 className="text-xl font-bold">Gallery</h3>
                    <div className="grid grid-cols-2 gap-4 md:grid-cols-3">
                      {trek.gallery.map((image: string, index: number) => (
                        <div key={index} className="aspect-square overflow-hidden rounded-lg">
                          <Image
                            src={image || "/placeholder.svg"}
                            alt={`${trek.title} - Image ${index + 1}`}
                            width={300}
                            height={300}
                            className="h-full w-full object-cover transition-transform hover:scale-105"
                          />
                        </div>
                      ))}
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="itinerary" className="mt-6 space-y-6">
                  <h2 className="text-2xl font-bold">Trek Itinerary</h2>
                  <div className="space-y-6">
                    {trek.itinerary.map((day: any, index: number) => (
                      <div key={index} className="space-y-2">
                        <h3 className="flex items-center gap-2 text-lg font-semibold">
                          <span className="flex h-6 w-6 items-center justify-center rounded-full bg-primary text-xs text-primary-foreground">
                            {index + 1}
                          </span>
                          Day {index + 1}: {day.title}
                        </h3>
                        <p className="text-muted-foreground">{day.description}</p>
                        <div className="flex flex-wrap gap-2 pt-1">
                          {day.distance && (
                            <Badge variant="outline" className="flex items-center gap-1">
                              <Clock className="h-3 w-3" /> {day.distance} km
                            </Badge>
                          )}
                          {day.elevation && (
                            <Badge variant="outline" className="flex items-center gap-1">
                              <Mountain className="h-3 w-3" /> {day.elevation}m gain
                            </Badge>
                          )}
                          {day.duration && (
                            <Badge variant="outline" className="flex items-center gap-1">
                              <Clock className="h-3 w-3" /> {day.duration} hrs
                            </Badge>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </TabsContent>

                <TabsContent value="inclusions" className="mt-6 space-y-6">
                  <div className="space-y-4">
                    <h2 className="text-2xl font-bold">What's Included</h2>
                    <ul className="ml-6 list-disc space-y-2 text-muted-foreground">
                      {trek.inclusions.map((item: string, index: number) => (
                        <li key={index}>{item}</li>
                      ))}
                    </ul>
                  </div>

                  <div className="space-y-4">
                    <h2 className="text-2xl font-bold">What's Not Included</h2>
                    <ul className="ml-6 list-disc space-y-2 text-muted-foreground">
                      {trek.exclusions.map((item: string, index: number) => (
                        <li key={index}>{item}</li>
                      ))}
                    </ul>
                  </div>
                </TabsContent>

                <TabsContent value="reviews" className="mt-6 space-y-6">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <h2 className="text-2xl font-bold">Trekker Reviews</h2>
                      <div className="flex items-center gap-2">
                        <div className="flex items-center">
                          {Array(5)
                            .fill(0)
                            .map((_, i) => (
                              <Star
                                key={i}
                                className={`h-5 w-5 ${
                                  i < Math.floor(trek.rating) ? "fill-yellow-400 text-yellow-400" : "text-gray-300"
                                }`}
                              />
                            ))}
                        </div>
                        <span className="font-medium">{trek.rating} out of 5</span>
                      </div>
                    </div>

                    <div className="space-y-3">
                      {trek.reviews.map((review: any, index: number) => (
                        <div key={index} className="space-y-2 rounded-lg border p-4">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-3">
                              <div className="relative h-10 w-10 overflow-hidden rounded-full">
                                <Image
                                  src={review.avatar || "/placeholder.svg"}
                                  alt={review.name}
                                  fill
                                  className="object-cover"
                                />
                              </div>
                              <div>
                                <p className="font-medium">{review.name}</p>
                                <p className="text-xs text-muted-foreground">{review.date}</p>
                              </div>
                            </div>
                            <div className="flex items-center">
                              {Array(5)
                                .fill(0)
                                .map((_, i) => (
                                  <Star
                                    key={i}
                                    className={`h-4 w-4 ${
                                      i < review.rating ? "fill-yellow-400 text-yellow-400" : "text-gray-300"
                                    }`}
                                  />
                                ))}
                            </div>
                          </div>
                          <p className="text-muted-foreground">{review.comment}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              <Card>
                <CardContent className="p-6">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-muted-foreground">Price starts from</p>
                        <p className="text-2xl font-bold">₹{trek.price.toLocaleString()}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm text-muted-foreground">Per person</p>
                        <p className="text-sm font-medium">{trek.duration} days</p>
                      </div>
                    </div>

                    <Separator />

                    <div className="space-y-2">
                      <h3 className="font-medium">Upcoming Batches</h3>
                      <div className="space-y-2">
                        {trek.batches.map((batch: any, index: number) => (
                          <div key={index} className="flex items-center justify-between rounded-md border p-3">
                            <div>
                              <p className="font-medium">{batch.date}</p>
                              <div className="flex items-center gap-1 text-xs text-muted-foreground">
                                <Users className="h-3 w-3" /> {batch.spotsLeft} spots left
                              </div>
                            </div>
                            <Badge variant={batch.spotsLeft < 5 ? "destructive" : "outline"}>
                              {batch.spotsLeft < 5 ? "Filling Fast" : "Available"}
                            </Badge>
                          </div>
                        ))}
                      </div>
                    </div>

                    <Button className="w-full" size="lg" onClick={handleBookNow}>
                      Book Now
                    </Button>

                    <div className="rounded-md bg-muted p-3">
                      <div className="flex items-center justify-between">
                        <p className="text-sm font-medium">Booking Progress</p>
                        <p className="text-xs text-muted-foreground">75% booked</p>
                      </div>
                      <Progress value={75} className="mt-2 h-2" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <h3 className="mb-4 font-medium">Need Help?</h3>
                  <div className="space-y-3">
                    <div className="flex items-start gap-3">
                      <Wallet className="h-5 w-5 text-primary" />
                      <div>
                        <p className="font-medium">Flexible Payment</p>
                        <p className="text-sm text-muted-foreground">Pay 30% now, rest later</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <Calendar className="h-5 w-5 text-primary" />
                      <div>
                        <p className="font-medium">Free Cancellation</p>
                        <p className="text-sm text-muted-foreground">Cancel up to 30 days before</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <Users className="h-5 w-5 text-primary" />
                      <div>
                        <p className="font-medium">Expert Guides</p>
                        <p className="text-sm text-muted-foreground">Certified mountain guides</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>

      <BookingForm isOpen={isBookingOpen} onClose={() => setIsBookingOpen(false)} trek={trek} />
    </div>
  )
}
