"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import Image from "next/image"
import Link from "next/link"
import { Calendar, MapPin } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import Header from "@/components/header"
import ProfileSidebar from "@/components/profile-sidebar"
import { useAuth } from "@/context/auth-context"
import { treks } from "@/data/treks"

export default function BookingsPage() {
  const { isAuthenticated } = useAuth()
  const router = useRouter()

  useEffect(() => {
    if (!isAuthenticated) {
      router.push("/login")
    }
  }, [isAuthenticated, router])

  if (!isAuthenticated) {
    return null
  }

  // Sample booking data
  const upcomingBookings = [
    {
      id: 1,
      trekId: 1,
      date: "July 15-20, 2025",
      participants: 2,
      status: "confirmed",
      paymentStatus: "paid",
      bookingDate: "March 15, 2025",
    },
    {
      id: 2,
      trekId: 3,
      date: "December 20-25, 2025",
      participants: 1,
      status: "pending",
      paymentStatus: "partial",
      bookingDate: "April 2, 2025",
    },
  ]

  const pastBookings = [
    {
      id: 3,
      trekId: 2,
      date: "August 5-9, 2024",
      participants: 3,
      status: "completed",
      paymentStatus: "paid",
      bookingDate: "May 10, 2024",
    },
  ]

  const cancelledBookings = []

  return (
    <div className="flex min-h-screen flex-col">
      <Header />

      <div className="container py-8">
        <div className="grid grid-cols-1 gap-8 md:grid-cols-[240px_1fr]">
          <ProfileSidebar />

          <main className="space-y-6">
            <div>
              <h1 className="text-3xl font-bold">My Bookings</h1>
              <p className="text-muted-foreground">Manage your trek bookings and reservations</p>
            </div>

            <Tabs defaultValue="upcoming">
              <TabsList>
                <TabsTrigger value="upcoming">Upcoming</TabsTrigger>
                <TabsTrigger value="past">Past</TabsTrigger>
                <TabsTrigger value="cancelled">Cancelled</TabsTrigger>
              </TabsList>

              <TabsContent value="upcoming" className="space-y-6 pt-4">
                {upcomingBookings.length > 0 ? (
                  <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
                    {upcomingBookings.map((booking) => {
                      const trek = treks.find((t) => t.id === booking.trekId)
                      if (!trek) return null

                      return (
                        <Card key={booking.id}>
                          <div className="aspect-video relative">
                            <Image
                              src={trek.coverImage || "/placeholder.svg"}
                              alt={trek.title}
                              fill
                              className="object-cover rounded-t-lg"
                            />
                            <Badge
                              className={`absolute top-3 right-3 ${
                                booking.status === "confirmed"
                                  ? "bg-green-500"
                                  : booking.status === "pending"
                                    ? "bg-yellow-500"
                                    : "bg-blue-500"
                              }`}
                            >
                              {booking.status.charAt(0).toUpperCase() + booking.status.slice(1)}
                            </Badge>
                          </div>
                          <CardHeader className="pb-2">
                            <CardTitle>{trek.title}</CardTitle>
                            <div className="flex items-center text-sm text-muted-foreground">
                              <MapPin className="mr-1 h-4 w-4" />
                              {trek.location}
                            </div>
                          </CardHeader>
                          <CardContent className="pb-2 space-y-2">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center text-sm">
                                <Calendar className="mr-1 h-4 w-4 text-muted-foreground" />
                                <span>{booking.date}</span>
                              </div>
                              <Badge variant="outline">
                                {booking.participants} {booking.participants === 1 ? "Person" : "People"}
                              </Badge>
                            </div>
                            <div className="flex justify-between text-sm">
                              <span className="text-muted-foreground">Booking Date: {booking.bookingDate}</span>
                              <span
                                className={`font-medium ${
                                  booking.paymentStatus === "paid"
                                    ? "text-green-600"
                                    : booking.paymentStatus === "partial"
                                      ? "text-amber-600"
                                      : "text-red-600"
                                }`}
                              >
                                {booking.paymentStatus === "paid"
                                  ? "Paid"
                                  : booking.paymentStatus === "partial"
                                    ? "Partially Paid"
                                    : "Unpaid"}
                              </span>
                            </div>
                          </CardContent>
                          <CardFooter className="flex justify-between">
                            <Button variant="outline" asChild>
                              <Link href={`/treks/${trek.slug}`}>View Trek</Link>
                            </Button>
                            <Button>Manage Booking</Button>
                          </CardFooter>
                        </Card>
                      )
                    })}
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center py-12 text-center">
                    <div className="rounded-full bg-muted p-6">
                      <Calendar className="h-10 w-10 text-muted-foreground" />
                    </div>
                    <h3 className="mt-4 text-lg font-medium">No upcoming bookings</h3>
                    <p className="mt-2 text-sm text-muted-foreground">
                      You don't have any upcoming treks. Explore our treks and book your next adventure!
                    </p>
                    <Button className="mt-4" asChild>
                      <Link href="/#treks">Explore Treks</Link>
                    </Button>
                  </div>
                )}
              </TabsContent>

              <TabsContent value="past" className="space-y-6 pt-4">
                {pastBookings.length > 0 ? (
                  <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
                    {pastBookings.map((booking) => {
                      const trek = treks.find((t) => t.id === booking.trekId)
                      if (!trek) return null

                      return (
                        <Card key={booking.id}>
                          <div className="aspect-video relative">
                            <Image
                              src={trek.coverImage || "/placeholder.svg"}
                              alt={trek.title}
                              fill
                              className="object-cover rounded-t-lg"
                            />
                            <Badge className="absolute top-3 right-3 bg-blue-500">Completed</Badge>
                          </div>
                          <CardHeader className="pb-2">
                            <CardTitle>{trek.title}</CardTitle>
                            <div className="flex items-center text-sm text-muted-foreground">
                              <MapPin className="mr-1 h-4 w-4" />
                              {trek.location}
                            </div>
                          </CardHeader>
                          <CardContent className="pb-2 space-y-2">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center text-sm">
                                <Calendar className="mr-1 h-4 w-4 text-muted-foreground" />
                                <span>{booking.date}</span>
                              </div>
                              <Badge variant="outline">
                                {booking.participants} {booking.participants === 1 ? "Person" : "People"}
                              </Badge>
                            </div>
                            <div className="flex justify-between text-sm">
                              <span className="text-muted-foreground">Booking Date: {booking.bookingDate}</span>
                              <span className="font-medium text-green-600">Paid</span>
                            </div>
                          </CardContent>
                          <CardFooter className="flex justify-between">
                            <Button variant="outline" asChild>
                              <Link href={`/treks/${trek.slug}`}>View Trek</Link>
                            </Button>
                            <Button variant="secondary">Write Review</Button>
                          </CardFooter>
                        </Card>
                      )
                    })}
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center py-12 text-center">
                    <div className="rounded-full bg-muted p-6">
                      <Calendar className="h-10 w-10 text-muted-foreground" />
                    </div>
                    <h3 className="mt-4 text-lg font-medium">No past bookings</h3>
                    <p className="mt-2 text-sm text-muted-foreground">
                      You haven't completed any treks with us yet. Book your first adventure now!
                    </p>
                    <Button className="mt-4" asChild>
                      <Link href="/#treks">Explore Treks</Link>
                    </Button>
                  </div>
                )}
              </TabsContent>

              <TabsContent value="cancelled" className="space-y-6 pt-4">
                {cancelledBookings.length > 0 ? (
                  <div className="grid grid-cols-1 gap-6 md:grid-cols-2">{/* Cancelled bookings would go here */}</div>
                ) : (
                  <div className="flex flex-col items-center justify-center py-12 text-center">
                    <div className="rounded-full bg-muted p-6">
                      <Calendar className="h-10 w-10 text-muted-foreground" />
                    </div>
                    <h3 className="mt-4 text-lg font-medium">No cancelled bookings</h3>
                    <p className="mt-2 text-sm text-muted-foreground">
                      You don't have any cancelled bookings. That's great!
                    </p>
                  </div>
                )}
              </TabsContent>
            </Tabs>
          </main>
        </div>
      </div>
    </div>
  )
}
