"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { Camera, User } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Separator } from "@/components/ui/separator"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import Header from "@/components/header"
import { useAuth } from "@/context/auth-context"
import ProfileSidebar from "@/components/profile-sidebar"

export default function ProfilePage() {
  const { user, isAuthenticated } = useAuth()
  const router = useRouter()

  useEffect(() => {
    if (!isAuthenticated) {
      router.push("/login")
    }
  }, [isAuthenticated, router])

  if (!isAuthenticated) {
    return null
  }

  return (
    <div className="flex min-h-screen flex-col">
      <Header />

      <div className="container py-8">
        <div className="grid grid-cols-1 gap-8 md:grid-cols-[240px_1fr]">
          <ProfileSidebar />

          <main className="space-y-6">
            <div>
              <h1 className="text-3xl font-bold">My Profile</h1>
              <p className="text-muted-foreground">Manage your account settings and preferences</p>
            </div>

            <Tabs defaultValue="personal">
              <TabsList>
                <TabsTrigger value="personal">Personal Info</TabsTrigger>
                <TabsTrigger value="preferences">Preferences</TabsTrigger>
                <TabsTrigger value="security">Security</TabsTrigger>
              </TabsList>

              <TabsContent value="personal" className="space-y-6 pt-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Profile Picture</CardTitle>
                    <CardDescription>Update your profile picture</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center gap-6">
                      <Avatar className="h-24 w-24">
                        <AvatarImage src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=100&h=100&auto=format&fit=crop" />
                        <AvatarFallback>
                          <User className="h-12 w-12" />
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <Button variant="outline" className="mb-2">
                          <Camera className="mr-2 h-4 w-4" /> Upload New Photo
                        </Button>
                        <p className="text-xs text-muted-foreground">JPG, GIF or PNG. Max size 2MB.</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Personal Information</CardTitle>
                    <CardDescription>Update your personal details</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <form className="space-y-4">
                      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                        <div className="space-y-2">
                          <Label htmlFor="fullName">Full Name</Label>
                          <Input id="fullName" placeholder="John Doe" defaultValue="Priya Sharma" />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="email">Email</Label>
                          <Input id="email" type="email" defaultValue={user} disabled />
                          <p className="text-xs text-muted-foreground">
                            Your email address is used for login and cannot be changed
                          </p>
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="phone">Phone Number</Label>
                          <Input id="phone" placeholder="+91 98765 43210" defaultValue="+91 98765 43210" />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="dob">Date of Birth</Label>
                          <Input id="dob" type="date" defaultValue="1990-01-15" />
                        </div>
                      </div>

                      <Separator />

                      <div className="space-y-2">
                        <Label htmlFor="address">Address</Label>
                        <Textarea
                          id="address"
                          placeholder="Enter your address"
                          defaultValue="123 Mountain View, Bangalore, Karnataka, India - 560001"
                        />
                      </div>

                      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
                        <div className="space-y-2">
                          <Label htmlFor="city">City</Label>
                          <Input id="city" defaultValue="Bangalore" />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="state">State</Label>
                          <Input id="state" defaultValue="Karnataka" />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="pincode">Pincode</Label>
                          <Input id="pincode" defaultValue="560001" />
                        </div>
                      </div>

                      <div className="flex justify-end">
                        <Button>Save Changes</Button>
                      </div>
                    </form>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="preferences" className="space-y-6 pt-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Trek Preferences</CardTitle>
                    <CardDescription>Customize your trekking preferences</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <form className="space-y-4">
                      <div className="space-y-2">
                        <Label>Preferred Trek Difficulty</Label>
                        <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
                          <div className="flex items-center space-x-2">
                            <input type="checkbox" id="easy" defaultChecked />
                            <Label htmlFor="easy">Easy</Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <input type="checkbox" id="moderate" defaultChecked />
                            <Label htmlFor="moderate">Moderate</Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <input type="checkbox" id="difficult" />
                            <Label htmlFor="difficult">Difficult</Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <input type="checkbox" id="challenging" />
                            <Label htmlFor="challenging">Challenging</Label>
                          </div>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label>Preferred Trek Duration</Label>
                        <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
                          <div className="flex items-center space-x-2">
                            <input type="checkbox" id="weekend" defaultChecked />
                            <Label htmlFor="weekend">Weekend (2-3 days)</Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <input type="checkbox" id="short" defaultChecked />
                            <Label htmlFor="short">Short (4-6 days)</Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <input type="checkbox" id="medium" />
                            <Label htmlFor="medium">Medium (7-10 days)</Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <input type="checkbox" id="long" />
                            <Label htmlFor="long">Long (10+ days)</Label>
                          </div>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label>Interests</Label>
                        <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
                          <div className="flex items-center space-x-2">
                            <input type="checkbox" id="photography" defaultChecked />
                            <Label htmlFor="photography">Photography</Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <input type="checkbox" id="wildlife" />
                            <Label htmlFor="wildlife">Wildlife</Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <input type="checkbox" id="camping" defaultChecked />
                            <Label htmlFor="camping">Camping</Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <input type="checkbox" id="culture" />
                            <Label htmlFor="culture">Local Culture</Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <input type="checkbox" id="adventure" defaultChecked />
                            <Label htmlFor="adventure">Adventure</Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <input type="checkbox" id="meditation" />
                            <Label htmlFor="meditation">Meditation/Yoga</Label>
                          </div>
                        </div>
                      </div>

                      <div className="flex justify-end">
                        <Button>Save Preferences</Button>
                      </div>
                    </form>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Notification Settings</CardTitle>
                    <CardDescription>Manage your notification preferences</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <form className="space-y-4">
                      <div className="space-y-4">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="font-medium">Email Notifications</p>
                            <p className="text-sm text-muted-foreground">Receive emails about new treks and offers</p>
                          </div>
                          <input type="checkbox" defaultChecked />
                        </div>
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="font-medium">SMS Notifications</p>
                            <p className="text-sm text-muted-foreground">Receive text messages about your bookings</p>
                          </div>
                          <input type="checkbox" defaultChecked />
                        </div>
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="font-medium">Marketing Communications</p>
                            <p className="text-sm text-muted-foreground">Receive marketing emails and newsletters</p>
                          </div>
                          <input type="checkbox" />
                        </div>
                      </div>

                      <div className="flex justify-end">
                        <Button>Save Settings</Button>
                      </div>
                    </form>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="security" className="space-y-6 pt-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Change Password</CardTitle>
                    <CardDescription>Update your password</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <form className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="currentPassword">Current Password</Label>
                        <Input id="currentPassword" type="password" />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="newPassword">New Password</Label>
                        <Input id="newPassword" type="password" />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="confirmPassword">Confirm New Password</Label>
                        <Input id="confirmPassword" type="password" />
                      </div>
                      <div className="flex justify-end">
                        <Button>Update Password</Button>
                      </div>
                    </form>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Two-Factor Authentication</CardTitle>
                    <CardDescription>Add an extra layer of security to your account</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">Two-Factor Authentication</p>
                          <p className="text-sm text-muted-foreground">
                            Secure your account with two-factor authentication
                          </p>
                        </div>
                        <Button variant="outline">Enable</Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </main>
        </div>
      </div>
    </div>
  )
}
