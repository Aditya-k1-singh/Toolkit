import Link from "next/link"
import Image from "next/image"
import { MapPin, Calendar, Users, ArrowRight } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import TrekCard from "@/components/trek-card"
import TestimonialCard from "@/components/testimonial-card"
import SearchFilters from "@/components/search-filters"
import RecommendationSystem from "@/components/recommendation-system"
import Header from "@/components/header"

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col">
      <Header />

      <main className="flex-1">
        {/* Hero/Jumbotron */}
        <section className="relative">
          <div className="absolute inset-0 z-0">
            <Image
              src="https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?q=80&w=1920&h=800&auto=format&fit=crop"
              alt="Mountains landscape"
              fill
              className="object-cover brightness-50"
              priority
            />
          </div>
          <div className="container relative z-10 py-24 md:py-32 lg:py-40">
            <div className="max-w-3xl space-y-5 text-white">
              <h1 className="text-4xl font-bold tracking-tighter sm:text-5xl md:text-6xl">
                Discover the Beauty of India's Mountains
              </h1>
              <p className="text-lg md:text-xl text-gray-200">
                Join our expert-led treks to the most breathtaking locations across India. From the majestic Himalayas
                to the lush Western Ghats.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button size="lg" className="w-full sm:w-auto">
                  Explore Treks
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  className="w-full sm:w-auto border-white text-white hover:bg-white hover:text-black"
                >
                  Contact Us
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Search & Recommendation System */}
        <section className="container py-12">
          <div className="rounded-xl border bg-card p-6 shadow-sm">
            <Tabs defaultValue="search">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="search">Search Treks</TabsTrigger>
                <TabsTrigger value="recommend">Get Recommendations</TabsTrigger>
              </TabsList>
              <TabsContent value="search" className="mt-6">
                <SearchFilters />
              </TabsContent>
              <TabsContent value="recommend" className="mt-6">
                <RecommendationSystem />
              </TabsContent>
            </Tabs>
          </div>
        </section>

        {/* Featured Treks */}
        <section id="treks" className="container py-12 md:py-16">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
            <div>
              <h2 className="text-3xl font-bold tracking-tight">Featured Treks</h2>
              <p className="text-muted-foreground mt-1">Explore our most popular trekking destinations</p>
            </div>
            <Link href="/all-treks" className="flex items-center gap-1 text-primary hover:underline">
              View all treks <ArrowRight className="h-4 w-4" />
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <TrekCard
              title="Valley of Flowers"
              location="Uttarakhand"
              image="https://images.unsplash.com/photo-1501555088652-021faa106b9b?q=80&w=600&h=400&auto=format&fit=crop"
              price={12500}
              duration={6}
              difficulty="Moderate"
              rating={4.8}
              season="Monsoon"
              slug="valley-of-flowers"
            />
            <TrekCard
              title="Hampta Pass"
              location="Himachal Pradesh"
              image="https://images.unsplash.com/photo-1486870591958-9b9d0d1dda99?q=80&w=600&h=400&auto=format&fit=crop"
              price={14800}
              duration={5}
              difficulty="Moderate"
              rating={4.7}
              season="Summer"
              slug="hampta-pass"
            />
            <TrekCard
              title="Kedarkantha"
              location="Uttarakhand"
              image="https://images.unsplash.com/photo-1483728642387-6c3bdd6c93e5?q=80&w=600&h=400&auto=format&fit=crop"
              price={9800}
              duration={6}
              difficulty="Easy to Moderate"
              rating={4.9}
              season="Winter"
              slug="kedarkantha"
            />
            <TrekCard
              title="Sandakphu"
              location="West Bengal"
              image="https://images.unsplash.com/photo-1464278533981-50106e6176b1?q=80&w=600&h=400&auto=format&fit=crop"
              price={15500}
              duration={7}
              difficulty="Moderate to Difficult"
              rating={4.6}
              season="Spring/Autumn"
              slug="sandakphu"
            />
            <TrekCard
              title="Tarsar Marsar"
              location="Kashmir"
              image="https://images.unsplash.com/photo-1526772662000-3f88f10405ff?q=80&w=600&h=400&auto=format&fit=crop"
              price={18900}
              duration={7}
              difficulty="Moderate"
              rating={4.9}
              season="Summer"
              slug="tarsar-marsar"
            />
            <TrekCard
              title="Kudremukh"
              location="Karnataka"
              image="https://images.unsplash.com/photo-1455156218388-5e61b526818b?q=80&w=600&h=400&auto=format&fit=crop"
              price={7500}
              duration={3}
              difficulty="Moderate"
              rating={4.5}
              season="Winter"
              slug="kudremukh"
            />
          </div>
        </section>

        {/* Upcoming Treks */}
        <section id="upcoming" className="bg-muted py-12 md:py-16">
          <div className="container">
            <h2 className="text-3xl font-bold tracking-tight mb-8">Upcoming Treks</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <Card>
                <CardHeader className="pb-3">
                  <div className="flex justify-between items-start">
                    <CardTitle>Roopkund Trek</CardTitle>
                    <Badge>Limited Spots</Badge>
                  </div>
                  <CardDescription>Uttarakhand | 15-22 June 2025</CardDescription>
                </CardHeader>
                <CardContent className="pb-3">
                  <div className="aspect-video relative rounded-md overflow-hidden mb-3">
                    <Image
                      src="https://images.unsplash.com/photo-1580136579312-94651dfd596d?q=80&w=500&h=300&auto=format&fit=crop"
                      alt="Roopkund Trek"
                      fill
                      className="object-cover"
                    />
                  </div>
                  <div className="flex justify-between text-sm">
                    <div className="flex items-center gap-1">
                      <Calendar className="h-4 w-4 text-muted-foreground" />
                      <span>7 Days</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Users className="h-4 w-4 text-muted-foreground" />
                      <span>8 spots left</span>
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="flex justify-between">
                  <p className="font-semibold">₹16,500</p>
                  <Button size="sm">Book Now</Button>
                </CardFooter>
              </Card>

              <Card>
                <CardHeader className="pb-3">
                  <CardTitle>Goechala Trek</CardTitle>
                  <CardDescription>Sikkim | 5-15 July 2025</CardDescription>
                </CardHeader>
                <CardContent className="pb-3">
                  <div className="aspect-video relative rounded-md overflow-hidden mb-3">
                    <Image
                      src="https://images.unsplash.com/photo-1580977276076-ae4b8c219b8e?q=80&w=500&h=300&auto=format&fit=crop"
                      alt="Goechala Trek"
                      fill
                      className="object-cover"
                    />
                  </div>
                  <div className="flex justify-between text-sm">
                    <div className="flex items-center gap-1">
                      <Calendar className="h-4 w-4 text-muted-foreground" />
                      <span>10 Days</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Users className="h-4 w-4 text-muted-foreground" />
                      <span>12 spots left</span>
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="flex justify-between">
                  <p className="font-semibold">₹22,800</p>
                  <Button size="sm">Book Now</Button>
                </CardFooter>
              </Card>

              <Card>
                <CardHeader className="pb-3">
                  <CardTitle>Chadar Frozen River Trek</CardTitle>
                  <CardDescription>Ladakh | 15-25 January 2026</CardDescription>
                </CardHeader>
                <CardContent className="pb-3">
                  <div className="aspect-video relative rounded-md overflow-hidden mb-3">
                    <Image
                      src="https://images.unsplash.com/photo-1515876305430-f06edab8282a?q=80&w=500&h=300&auto=format&fit=crop"
                      alt="Chadar Frozen River Trek"
                      fill
                      className="object-cover"
                    />
                  </div>
                  <div className="flex justify-between text-sm">
                    <div className="flex items-center gap-1">
                      <Calendar className="h-4 w-4 text-muted-foreground" />
                      <span>10 Days</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Users className="h-4 w-4 text-muted-foreground" />
                      <span>5 spots left</span>
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="flex justify-between">
                  <p className="font-semibold">₹28,500</p>
                  <Button size="sm">Book Now</Button>
                </CardFooter>
              </Card>
            </div>
          </div>
        </section>

        {/* Recent Treks */}
        <section id="recent" className="container py-12 md:py-16">
          <h2 className="text-3xl font-bold tracking-tight mb-8">Recent Expeditions</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="relative rounded-xl overflow-hidden">
              <Image
                src="https://images.unsplash.com/photo-1506905925346-21bda4d32df4?q=80&w=800&h=500&auto=format&fit=crop"
                alt="Recent Trek"
                width={800}
                height={500}
                className="object-cover aspect-[4/3]"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent flex flex-col justify-end p-6 text-white">
                <h3 className="text-xl font-bold mb-2">Markha Valley Trek</h3>
                <p className="text-sm mb-3">
                  Our team just returned from an amazing journey through the Markha Valley in Ladakh.
                </p>
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className="text-white border-white">
                    April 2025
                  </Badge>
                  <Badge variant="outline" className="text-white border-white">
                    15 Trekkers
                  </Badge>
                </div>
              </div>
            </div>
            <div className="relative rounded-xl overflow-hidden">
              <Image
                src="https://images.unsplash.com/photo-1454496522488-7a8e488e8606?q=80&w=800&h=500&auto=format&fit=crop"
                alt="Recent Trek"
                width={800}
                height={500}
                className="object-cover aspect-[4/3]"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent flex flex-col justify-end p-6 text-white">
                <h3 className="text-xl font-bold mb-2">Dzukou Valley</h3>
                <p className="text-sm mb-3">
                  Explored the stunning Dzukou Valley on the border of Nagaland and Manipur.
                </p>
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className="text-white border-white">
                    March 2025
                  </Badge>
                  <Badge variant="outline" className="text-white border-white">
                    12 Trekkers
                  </Badge>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Testimonials */}
        <section id="testimonials" className="bg-muted py-12 md:py-16">
          <div className="container">
            <h2 className="text-3xl font-bold tracking-tight mb-8">What Our Trekkers Say</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <TestimonialCard
                name="Priya Sharma"
                trek="Valley of Flowers"
                image="https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=100&h=100&auto=format&fit=crop"
                rating={5}
                testimonial="The Valley of Flowers trek was beyond my expectations. The guides were knowledgeable and the arrangements were perfect. Will definitely trek with TrekIndia again!"
              />
              <TestimonialCard
                name="Rahul Mehta"
                trek="Hampta Pass"
                image="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=100&h=100&auto=format&fit=crop"
                rating={4}
                testimonial="Crossing the Hampta Pass was challenging but the views were worth it. The team ensured our safety throughout the journey. Great experience overall."
              />
              <TestimonialCard
                name="Anjali Patel"
                trek="Kedarkantha"
                image="https://images.unsplash.com/photo-1438761681033-6461ffad8d80?q=80&w=100&h=100&auto=format&fit=crop"
                rating={5}
                testimonial="As a first-time trekker, I was nervous, but the team made me feel comfortable. The winter trek to Kedarkantha was magical. Highly recommend!"
              />
            </div>
          </div>
        </section>

        {/* Contact Us */}
        <section id="contact" className="container py-12 md:py-16">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div>
              <h2 className="text-3xl font-bold tracking-tight mb-4">Contact Us</h2>
              <p className="text-muted-foreground mb-6">
                Have questions about our treks or need custom itineraries? Get in touch with our team and we'll help you
                plan your perfect adventure.
              </p>

              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <MapPin className="h-5 w-5 text-primary mt-0.5" />
                  <div>
                    <h3 className="font-medium">Our Office</h3>
                    <p className="text-muted-foreground">123 Adventure Lane, Bangalore, Karnataka, India - 560001</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="20"
                    height="20"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="h-5 w-5 text-primary mt-0.5"
                  >
                    <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>
                  </svg>
                  <div>
                    <h3 className="font-medium">Phone</h3>
                    <p className="text-muted-foreground">+91 9876543210</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="20"
                    height="20"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="h-5 w-5 text-primary mt-0.5"
                  >
                    <rect width="20" height="16" x="2" y="4" rx="2"></rect>
                    <path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"></path>
                  </svg>
                  <div>
                    <h3 className="font-medium">Email</h3>
                    <p className="text-muted-foreground">info@trekindia.com</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="rounded-xl border bg-card p-6 shadow-sm">
              <h3 className="text-xl font-semibold mb-4">Send us a message</h3>
              <form className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label htmlFor="name" className="text-sm font-medium">
                      Name
                    </label>
                    <Input id="name" placeholder="Your name" />
                  </div>
                  <div className="space-y-2">
                    <label htmlFor="email" className="text-sm font-medium">
                      Email
                    </label>
                    <Input id="email" type="email" placeholder="Your email" />
                  </div>
                </div>
                <div className="space-y-2">
                  <label htmlFor="subject" className="text-sm font-medium">
                    Subject
                  </label>
                  <Input id="subject" placeholder="Subject of your message" />
                </div>
                <div className="space-y-2">
                  <label htmlFor="message" className="text-sm font-medium">
                    Message
                  </label>
                  <textarea
                    id="message"
                    className="flex min-h-[120px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                    placeholder="Your message"
                  ></textarea>
                </div>
                <Button type="submit" className="w-full">
                  Send Message
                </Button>
              </form>
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t bg-muted">
        <div className="container py-8 md:py-12">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="md:col-span-2">
              <Link href="/" className="flex items-center gap-2 font-bold text-xl mb-4">
                <MapPin className="h-6 w-6 text-primary" />
                <span>TrekIndia</span>
              </Link>
              <p className="text-muted-foreground mb-4 max-w-md">
                TrekIndia is your gateway to the most breathtaking trekking experiences across India. With expert guides
                and well-planned itineraries, we ensure unforgettable adventures.
              </p>
              <div className="flex gap-4">
                <Link href="#" className="text-muted-foreground hover:text-foreground">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="h-5 w-5"
                  >
                    <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"></path>
                  </svg>
                </Link>
                <Link href="#" className="text-muted-foreground hover:text-foreground">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="h-5 w-5"
                  >
                    <rect width="20" height="20" x="2" y="2" rx="5" ry="5"></rect>
                    <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path>
                    <line x1="17.5" x2="17.51" y1="6.5" y2="6.5"></line>
                  </svg>
                </Link>
                <Link href="#" className="text-muted-foreground hover:text-foreground">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="h-5 w-5"
                  >
                    <path d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z"></path>
                  </svg>
                </Link>
                <Link href="#" className="text-muted-foreground hover:text-foreground">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="h-5 w-5"
                  >
                    <path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"></path>
                    <rect width="4" height="12" x="2" y="9"></rect>
                    <circle cx="4" cy="4" r="2"></circle>
                  </svg>
                </Link>
              </div>
            </div>
            <div>
              <h3 className="font-semibold text-lg mb-4">Quick Links</h3>
              <ul className="space-y-2">
                <li>
                  <Link href="#" className="text-muted-foreground hover:text-foreground">
                    About Us
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground hover:text-foreground">
                    Our Team
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground hover:text-foreground">
                    Blog
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground hover:text-foreground">
                    Careers
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground hover:text-foreground">
                    FAQs
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold text-lg mb-4">Legal</h3>
              <ul className="space-y-2">
                <li>
                  <Link href="#" className="text-muted-foreground hover:text-foreground">
                    Terms & Conditions
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground hover:text-foreground">
                    Privacy Policy
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground hover:text-foreground">
                    Cancellation Policy
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground hover:text-foreground">
                    Safety Guidelines
                  </Link>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t mt-8 pt-8 text-center text-muted-foreground">
            <p>© {new Date().getFullYear()} TrekIndia. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
