"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import { useRouter } from "next/navigation"
import { useToast } from "@/components/ui/use-toast"

interface AuthContextType {
  user: string | null
  login: (email: string) => void
  logout: () => void
  isAuthenticated: boolean
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  login: () => {},
  logout: () => {},
  isAuthenticated: false,
})

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const router = useRouter()
  const { toast } = useToast()

  useEffect(() => {
    // Check if user is logged in from localStorage
    if (typeof window !== "undefined") {
      try {
        const storedUser = localStorage.getItem("user")
        if (storedUser) {
          setUser(storedUser)
        }
      } catch (error) {
        console.error("Error accessing localStorage:", error)
      }
      setIsLoading(false)
    }
  }, [])

  const login = (email: string) => {
    setUser(email)
    if (typeof window !== "undefined") {
      try {
        localStorage.setItem("user", email)
        toast({
          title: "Login successful",
          description: "Welcome back to TrekIndia!",
        })
      } catch (error) {
        console.error("Error setting localStorage:", error)
      }
    }
  }

  const logout = () => {
    setUser(null)
    if (typeof window !== "undefined") {
      try {
        localStorage.removeItem("user")
        toast({
          title: "Logged out",
          description: "You have been successfully logged out.",
        })
        router.push("/")
      } catch (error) {
        console.error("Error removing from localStorage:", error)
      }
    }
  }

  return (
    <AuthContext.Provider
      value={{
        user,
        login,
        logout,
        isAuthenticated: !!user,
      }}
    >
      {!isLoading && children}
    </AuthContext.Provider>
  )
}

export const useAuth = () => useContext(AuthContext)
